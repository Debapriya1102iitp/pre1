# Team Integration Guide for Sanskriti Dharohar

## 🎯 Quick Start for Teammates

### Problem 1: Image Solution ✅
**SOLVED**: All images now use **Pexels URLs** which are:
- ✅ Stable and permanent
- ✅ Work on GitHub/deployed sites
- ✅ Free to use commercially
- ✅ High quality and relevant

### Problem 2: JSON Integration ✅
**SOLVED**: Simple JSON format for easy team collaboration

---

## 📋 For Teammates: How to Add Your State Data

### Step 1: Use This JSON Template
Copy the template from `data-templates/state-template.json` and fill in your state's data:

```json
[
  {
    "id": "your-temple-id",
    "name": "Your Temple Name",
    "type": "Temple",
    "typeColor": "bg-orange-100 text-orange-800",
    "state": "Your State Name",
    "location": "City, District",
    "description": "Your description...",
    "image": "https://images.pexels.com/photos/XXXXX/pexels-photo-XXXXX.jpeg",
    // ... rest of the fields
  }
]
```

### Step 2: Type Colors to Use
- **Temples**: `"bg-orange-100 text-orange-800"`
- **Mosques**: `"bg-green-100 text-green-800"`
- **Churches**: `"bg-purple-100 text-purple-800"`
- **Gurudwaras**: `"bg-blue-100 text-blue-800"`

### Step 3: Image Guidelines
**Use only Pexels images:**
1. Go to [pexels.com](https://pexels.com)
2. Search for relevant images (temple, mosque, church, etc.)
3. Copy the image URL in this format: `https://images.pexels.com/photos/XXXXX/pexels-photo-XXXXX.jpeg`

### Step 4: Send Your JSON File
- Name your file: `[state-name]-sites.json`
- Example: `maharashtra-sites.json`, `rajasthan-sites.json`
- Send to the main developer for integration

---

## 🔧 For Main Developer: Integration Process

### Converting JSON to TypeScript
1. Receive JSON file from teammate
2. Create new TypeScript file: `src/data/[stateName]Sites.ts`
3. Use this template:

```typescript
import { ReligiousSite } from '../types';

export const [stateName]Sites: ReligiousSite[] = [
  // Paste JSON data here (remove quotes from keys)
];
```

### Adding to Main App
1. Import in `App.tsx`:
```typescript
import { [stateName]Sites } from './data/[stateName]Sites';
```

2. Add to `getSitesForState` function:
```typescript
if (stateId === '[state-id]') {
  return [stateName]Sites;
}
```

3. Add state to `src/data/states.ts`:
```typescript
{
  id: '[state-id]',
  name: '[State Name]',
  image: 'https://images.pexels.com/photos/XXXXX/pexels-photo-XXXXX.jpeg'
}
```

---

## 📝 Data Structure Explanation

### Required Fields
- `id`: Unique identifier (kebab-case)
- `name`: Full name of the religious site
- `type`: "Temple", "Mosque", "Church", or "Gurudwara"
- `typeColor`: Color scheme for the type badge
- `state`: Full state name
- `location`: City, District format
- `description`: Detailed description
- `image`: Pexels image URL

### Optional Fields
- `timings`: Opening hours
- `prasad`: Offerings/food available
- `amenities`: Array of facilities
- `festivals`: Array of celebrated festivals
- `contact`: Phone number
- `website`: Official website (if any)
- `nearestTransport`: Object with airport, railway, bus
- `nearbyAttractions`: Array of nearby places
- `nearbyHotels`: Array of accommodation options
- `nearbyRestaurants`: Array of dining options
- `specialFeatures`: Array of unique characteristics

---

## 🚀 Deployment Ready

### GitHub Upload
- All images use stable Pexels URLs
- No local image dependencies
- Works perfectly on GitHub Pages, Netlify, Vercel

### Team Collaboration
- Teammates work with simple JSON
- Main developer handles TypeScript conversion
- Clean separation of concerns
- Easy to maintain and update

---

## 📞 Support

If you need help:
1. Check this guide first
2. Look at existing state files as examples
3. Contact the main developer with specific questions

**Remember**: Keep it simple, use Pexels images, follow the JSON template!