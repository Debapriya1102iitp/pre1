import { ReligiousSite } from '../types';

export const karnatakaSites: ReligiousSite[] = [
  // TEMPLES
  {
    id: 'virupaksha-temple-hampi',
    name: 'Virupaksha Temple, Hampi',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Hampi, Ballari District',
    description: 'A magnificent ancient temple dedicated to Lord Virupaksha, a form of Shiva. It is the principal deity of the Hampi complex, a UNESCO World Heritage Site, and remains an active place of worship. Known for its towering gopuram and intricate carvings, it represents the pinnacle of Vijayanagara architecture.',
    image: '"C:\Users\DEBAPRIYA NAG\OneDrive\Pictures\Screenshots\Screenshot 2025-07-04 131116.png"',
    timings: 'Morning: 6:00 AM to 12:30 PM, Evening: 3:00 PM to 6:30 PM',
    prasad: 'Traditional offerings, Coconut prasadam, Temple sweets',
    amenities: [
      'Large courtyards and halls for devotees',
      'Counters for offerings',
      'Information boards and guides available',
      'Archaeological significance displays',
      'Walking paths through ruins',
      'Photography permitted in most areas'
    ],
    festivals: [
      'Hampi Festival (Vijayanagara Utsav)',
      'Maha Shivaratri',
      'Annual chariot festival',
      'Virupaksha Car Festival',
      'Traditional arts performances'
    ],
    contact: '+91 8394 241339',
    nearestTransport: {
      airport: 'Vidyanagar Airport (VDY) - 35 km, Hubballi Airport (HBX) - 160 km',
      railway: 'Hosapete Railway Station (HPT) - 13 km',
      bus: 'Hampi Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Hampi Bazaar',
      'Vittala Temple Complex',
      'Lotus Mahal',
      'Elephant Stables',
      'Matanga Hill',
      'Tungabhadra River'
    ],
    nearbyHotels: [
      'Hampi Heritage & Wilderness Resort',
      'Evolve Back Hampi',
      'Hotel Malligi',
      'Gopi Guesthouse'
    ],
    nearbyRestaurants: [
      'Mango Tree Restaurant',
      'Gopi Restaurant',
      'Laughing Buddha Restaurant',
      'Local South Indian eateries'
    ],
    specialFeatures: [
      'UNESCO World Heritage Site',
      'Continuous worship since 7th century',
      'Imposing 50-meter-high eastern gopuram',
      'Unique "pinhole camera" optical effect',
      'Blend of Chalukyan, Hoysala, and Dravidian styles',
      'Living temple within ruined city'
    ]
  },
  {
    id: 'chennakeshava-temple-belur',
    name: 'Chennakeshava Temple, Belur',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Belur, Hassan District',
    description: 'A masterpiece of Hoysala architecture, dedicated to Lord Vishnu as Chennakeshava (beautiful Vishnu). Commissioned by Hoysala King Vishnuvardhana in 1117 CE, it is renowned for its exquisite sculptures and intricate details, making it a UNESCO World Heritage site.',
    image: 'https://images.pexels.com/photos/12689000/pexels-photo-12689000.jpeg',
    timings: 'Morning: 6:00 AM to 1:00 PM, Evening: 4:00 PM to 7:30 PM',
    prasad: 'Vishnu prasadam, Traditional sweets, Sacred offerings',
    amenities: [
      'Information centre for tourists',
      'Resting areas with benches',
      'Ample parking space',
      'Official guides available',
      'Well-maintained pathways',
      'Archaeological museum nearby'
    ],
    festivals: [
      'Vaikuntha Ekadasi',
      'Rathotsava (chariot festival)',
      'Hoysala Mahotsava',
      'Krishna Janmashtami',
      'Annual temple celebrations'
    ],
    contact: '+91 8177 222218',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 130 km, Bengaluru Airport (BLR) - 220 km',
      railway: 'Hassan Junction (HAS) - 37 km',
      bus: 'Belur Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Halebidu Hoysaleswara Temple',
      'Shravanabelagola',
      'Yagachi Dam',
      'Gorur Dam',
      'Hassan city attractions'
    ],
    nearbyHotels: [
      'KSTDC Hotel Mayura Velapuri',
      'Hotel Suvarna Regency',
      'Hoysala Village Resort',
      'Local guesthouses'
    ],
    nearbyRestaurants: [
      'Hotel Suvarna Restaurant',
      'Local Karnataka cuisine eateries',
      'Traditional vegetarian restaurants',
      'KSTDC restaurant'
    ],
    specialFeatures: [
      'UNESCO World Heritage Site',
      'Star-shaped platform (jagati)',
      'Chloritic schist (soapstone) construction',
      'No two carvings are identical',
      'Celestial dancers (Shilabalikas) sculptures',
      'Signature Hoysala bell-shaped pillars'
    ]
  },
  {
    id: 'murudeshwara-shiva-temple',
    name: 'Murudeshwara Shiva Temple',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Murudeshwar, Uttara Kannada District',
    description: 'A modern temple complex featuring the second-tallest Shiva statue in the world (standing at 123 feet) and a towering gopuram. Situated on a hillock overlooking the Arabian Sea, it offers breathtaking views and a unique spiritual experience.',
    image: 'https://images.pexels.com/photos/12689001/pexels-photo-12689001.jpeg',
    timings: 'Morning: 6:00 AM to 1:00 PM, Evening: 3:00 PM to 8:00 PM',
    prasad: 'Shiva prasadam, Sacred ash, Temple offerings',
    amenities: [
      'Lift in Rajagopura for panoramic views',
      'Restaurants and food stalls',
      'Ample parking facilities',
      'Accessibility features with ramps',
      'Information center',
      'Beach access nearby'
    ],
    festivals: [
      'Maha Shivaratri',
      'Karthika Deepotsava',
      'Annual temple festival',
      'Shiva Ratri celebrations',
      'Cultural programs'
    ],
    contact: '+91 8385 260212',
    website: 'https://www.murudeshwar.org',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 160 km',
      railway: 'Murudeshwar Railway Station (MRDW) - 2 km',
      bus: 'Murudeshwar Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Murudeshwar Beach',
      'Netrani Island (scuba diving)',
      'Idagunji Ganapathi Temple',
      'Apsarakonda Falls',
      'Mirjan Fort'
    ],
    nearbyHotels: [
      'RNS Residency',
      'Naveen Beach Resort',
      'Murudeshwar International',
      'Sea view accommodations'
    ],
    nearbyRestaurants: [
      'Temple complex restaurants',
      'Coastal seafood restaurants',
      'Beach side eateries',
      'Local Karnataka cuisine'
    ],
    specialFeatures: [
      'Second-tallest Shiva statue in world (123 feet)',
      '20-storied Rajagopura with lift',
      'Stunning Arabian Sea location',
      'Modern engineering marvel',
      'Caves depicting Shiva stories',
      'Panoramic coastal views'
    ]
  },
  {
    id: 'chamundeshwari-temple-mysuru',
    name: 'Chamundeshwari Temple, Mysuru',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Chamundi Hills, Mysuru',
    description: 'A revered Hindu temple dedicated to Goddess Chamundeshwari, an incarnation of Durga. Perched atop the Chamundi Hills, it offers panoramic views of Mysuru city and is a significant pilgrimage site, especially during the Dasara festival.',
    image: 'https://images.pexels.com/photos/12689002/pexels-photo-12689002.jpeg',
    timings: 'Morning: 7:30 AM to 2:00 PM, Evening: 3:30 PM to 6:00 PM, Night: 7:30 PM to 9:00 PM',
    prasad: 'Chamundeshwari prasadam, Traditional sweets, Coconut offerings',
    amenities: [
      'Main shrine and prayer halls',
      'Counters for offerings',
      'Parking at hilltop',
      'Vehicle access available',
      'Monolithic Nandi statue viewing',
      'Panoramic city views'
    ],
    festivals: [
      'Mysuru Dasara',
      'Navaratri',
      'Chamundeshwari Jayanti',
      'Ashada Shukravara',
      'Annual temple festival'
    ],
    contact: '+91 821 2512271',
    nearestTransport: {
      airport: 'Mysuru Airport (MYQ) - 20 km, Bengaluru Airport (BLR) - 170 km',
      railway: 'Mysuru Junction (MYS) - 15 km',
      bus: 'Chamundi Hills Bus Service - Direct service from city'
    },
    nearbyAttractions: [
      'Mysuru Palace',
      'Monolithic Nandi statue',
      'Mahishasura statue',
      'Brindavan Gardens',
      'St. Philomena\'s Church',
      'Mysuru Zoo'
    ],
    nearbyHotels: [
      'Lalitha Mahal Palace Hotel',
      'Royal Orchid Metropole',
      'Hotel Pai Vista',
      'Mysuru city hotels'
    ],
    nearbyRestaurants: [
      'Mysuru city restaurants',
      'Traditional Karnataka eateries',
      'Palace area restaurants',
      'Local Mysuru cuisine'
    ],
    specialFeatures: [
      'Family deity of Mysuru royal family',
      'Central role in Mysuru Dasara',
      'Hilltop location with panoramic views',
      'Monolithic Nandi statue en route',
      'Seven-tiered gopuram',
      'Ancient Puranic significance'
    ]
  },
  {
    id: 'sri-krishna-matha-udupi',
    name: 'Sri Krishna Matha, Udupi',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Car Street, Udupi',
    description: 'A renowned Hindu temple complex dedicated to Lord Krishna, established by the great Dvaita philosopher Madhvacharya in the 13th century. It is unique for its "Kanakana Kindi" (Kanaka\'s window), through which devotees view the deity.',
    image: 'https://images.pexels.com/photos/12689003/pexels-photo-12689003.jpeg',
    timings: 'Morning: 5:30 AM to 1:00 PM, Evening: 3:00 PM to 9:00 PM',
    prasad: 'Krishna prasadam, Udupi cuisine specialties, Sacred offerings',
    amenities: [
      'Annadana hall for free meals',
      'Resting areas within complex',
      'Parking around temple area',
      'Educational facilities',
      'Madhwa Sarovara (temple pond)',
      'Ashta Mathas nearby'
    ],
    festivals: [
      'Krishna Janmashtami',
      'Paryaya Mahotsava',
      'Madhva Navami',
      'Rathotsava',
      'Vaikuntha Ekadasi'
    ],
    contact: '+91 820 2520021',
    website: 'https://www.udupi-krishna.org',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 60 km',
      railway: 'Udupi Railway Station (UD) - 5 km',
      bus: 'Udupi Bus Stand - 2 km'
    },
    nearbyAttractions: [
      'Malpe Beach',
      'St. Mary\'s Island',
      'Manipal University',
      'Anantheshwara Temple',
      'Chandramouleshwara Temple'
    ],
    nearbyHotels: [
      'Hotel Kidiyoor',
      'Hotel Udupi Residency',
      'Woodlands Hotel',
      'Paradise Isle Beach Resort'
    ],
    nearbyRestaurants: [
      'Mitra Samaj',
      'Woodlands Restaurant',
      'Diana Restaurant',
      'Traditional Udupi cuisine restaurants'
    ],
    specialFeatures: [
      'Founded by Jagadguru Madhvacharya',
      'Unique Kanakana Kindi viewing window',
      'Paryaya system of administration',
      'Center of Dvaita philosophy',
      'Ashta Mathas tradition',
      'Circular Car Street processions'
    ]
  },
  {
    id: 'kollur-mookambika-temple',
    name: 'Kollur Mookambika Temple',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Kollur, Udupi District',
    description: 'A highly revered Hindu temple dedicated to Goddess Mookambika, a manifestation of Shakti. Nestled amidst the scenic Western Ghats, it is a significant pilgrimage site for devotees from across South India, especially Kerala.',
    image: 'https://images.pexels.com/photos/12689004/pexels-photo-12689004.jpeg',
    timings: 'Morning: 6:00 AM to 2:00 PM, Evening: 3:00 PM to 8:30 PM',
    prasad: 'Mookambika prasadam, Sacred offerings, Traditional sweets',
    amenities: [
      'Annadana hall for free meals',
      'Pilgrim resting areas',
      'Parking facilities',
      'Golden flag staff viewing',
      'Natural surroundings',
      'Accommodation for pilgrims'
    ],
    festivals: [
      'Navaratri (Durga Puja)',
      'Maha Shivaratri',
      'Vidyarambham ceremony',
      'Annual Rathotsava',
      'Devi festivals'
    ],
    contact: '+91 8256 258001',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 140 km',
      railway: 'Mookambika Road Byndoor (BYNR) - 30 km, Kundapura (KUDA) - 40 km',
      bus: 'Kollur Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Kodachadri Hills',
      'Hidlumane Falls',
      'Kundadri Hills',
      'Agumbe Rainforest',
      'Sunset Point Kodachadri'
    ],
    nearbyHotels: [
      'KSTDC Mayura Sharavathi',
      'Mookambika Temple Guest House',
      'Local pilgrim accommodations',
      'Kollur lodges'
    ],
    nearbyRestaurants: [
      'Temple annadana',
      'Local vegetarian restaurants',
      'Pilgrim food centers',
      'Traditional South Indian eateries'
    ],
    specialFeatures: [
      'Associated with Adi Shankara',
      'Self-manifested (Swayambhu) idol',
      'Important Shakti Peetha',
      'Golden flag staff (Dhwajasthambha)',
      'Western Ghats mystical location',
      'Vidyarambham initiation ceremonies'
    ]
  },
  {
    id: 'iskcon-temple-bengaluru',
    name: 'ISKCON Temple, Bengaluru',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Hare Krishna Hill, Rajajinagar, Bengaluru',
    description: 'A grand and popular Vaishnava temple dedicated to Lord Krishna and Radha, part of the International Society for Krishna Consciousness (ISKCON). Known for its modern architecture, spiritual ambiance, and vibrant festivals.',
    image: 'https://images.pexels.com/photos/12689005/pexels-photo-12689005.jpeg',
    timings: 'Morning: 4:15 AM to 1:00 PM, Evening: 4:00 PM to 8:20 PM',
    prasad: 'Krishna prasadam, Govinda restaurant meals, Sacred offerings',
    amenities: [
      'Govinda restaurant',
      'Gift shop and bookstore',
      'Ample parking facilities',
      'Cultural center',
      'Guest house facilities',
      'Spiritual programs hall'
    ],
    festivals: [
      'Krishna Janmashtami',
      'Radhashtami',
      'Gaura Purnima',
      'Ratha Yatra',
      'Govardhan Puja'
    ],
    contact: '+91 80 2347 1956',
    website: 'https://www.iskconbangalore.org',
    nearestTransport: {
      airport: 'Kempegowda International Airport (BLR) - 40 km',
      railway: 'Bengaluru City Railway Station (SBC) - 8 km',
      bus: 'Rajajinagar Bus Stop - 2 km'
    },
    nearbyAttractions: [
      'Cubbon Park',
      'Lalbagh Botanical Garden',
      'Bangalore Palace',
      'Vidhana Soudha',
      'Commercial Street'
    ],
    nearbyHotels: [
      'The Leela Palace Bengaluru',
      'ITC Gardenia',
      'Taj West End',
      'Various city hotels'
    ],
    nearbyRestaurants: [
      'Govinda Restaurant (in temple)',
      'Bengaluru city restaurants',
      'Rajajinagar eateries',
      'International cuisine options'
    ],
    specialFeatures: [
      'Part of global ISKCON movement',
      'Modern temple architecture',
      'Elaborate daily rituals',
      'Cultural and educational programs',
      'Govinda restaurant famous for vegetarian food',
      'Active spiritual community'
    ]
  },
  {
    id: 'hoysaleswara-temple-halebidu',
    name: 'Hoysaleswara Temple, Halebidu',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Halebidu, Hassan District',
    description: 'A magnificent example of Hoysala architecture dedicated to Lord Shiva, built in the 12th century. Known for its intricate stone carvings, detailed sculptures, and twin temple structure. It is a UNESCO World Heritage Site and represents the pinnacle of Hoysala craftsmanship.',
    image: 'https://images.pexels.com/photos/12689007/pexels-photo-12689007.jpeg',
    timings: 'Morning: 6:00 AM to 6:00 PM',
    prasad: 'Shiva prasadam, Traditional offerings',
    amenities: [
      'Archaeological museum',
      'Information center',
      'Guided tours available',
      'Parking facilities',
      'Resting areas',
      'Photography permitted'
    ],
    festivals: [
      'Maha Shivaratri',
      'Hoysala Mahotsava',
      'Annual heritage festival',
      'Cultural programs'
    ],
    contact: '+91 8177 273114',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 150 km, Bengaluru Airport (BLR) - 210 km',
      railway: 'Hassan Junction (HAS) - 27 km',
      bus: 'Halebidu Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Belur Chennakeshava Temple',
      'Shravanabelagola',
      'Kedareswara Temple',
      'Jain Basadis',
      'Archaeological museum'
    ],
    nearbyHotels: [
      'KSTDC Mayura Shantala',
      'Hoysala Village Resort',
      'Local guesthouses',
      'Hassan city hotels'
    ],
    nearbyRestaurants: [
      'KSTDC restaurant',
      'Local Karnataka cuisine',
      'Traditional vegetarian eateries',
      'Heritage site cafeteria'
    ],
    specialFeatures: [
      'UNESCO World Heritage Site',
      'Twin temple structure',
      'Intricate soapstone carvings',
      'Detailed narrative sculptures',
      'Hoysala architectural pinnacle',
      'Star-shaped platform design'
    ]
  },
  {
    id: 'gomateshwara-statue-shravanabelagola',
    name: 'Gomateshwara Statue, Shravanabelagola',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Shravanabelagola, Hassan District',
    description: 'Home to the world\'s largest monolithic statue of Lord Gomateshwara (Bahubali), standing 57 feet tall. This Jain pilgrimage site atop Vindhyagiri Hill is over 1,000 years old and attracts devotees from around the world, especially during the Mahamastakabhisheka ceremony held every 12 years.',
    image: 'https://images.pexels.com/photos/12689008/pexels-photo-12689008.jpeg',
    timings: 'Morning: 6:00 AM to 6:00 PM',
    prasad: 'Jain offerings, Sacred rice, Traditional prasadam',
    amenities: [
      'Steps to hilltop (614 steps)',
      'Jain museum',
      'Dharamshala accommodation',
      'Parking at base',
      'Information center',
      'Guided tours'
    ],
    festivals: [
      'Mahamastakabhisheka (every 12 years)',
      'Paryushan Parva',
      'Mahavir Jayanti',
      'Diwali celebrations',
      'Annual Jain festivals'
    ],
    contact: '+91 8176 257238',
    nearestTransport: {
      airport: 'Bengaluru Airport (BLR) - 158 km',
      railway: 'Hassan Junction (HAS) - 51 km',
      bus: 'Shravanabelagola Bus Stand - 2 km'
    },
    nearbyAttractions: [
      'Chandragiri Hill',
      'Jain Basadis',
      'Bhandari Basadi',
      'Akkana Basadi',
      'Tyagada Brahmadeva Pillar'
    ],
    nearbyHotels: [
      'KSTDC Mayura Hoysala',
      'Jain Dharamshala',
      'Local guesthouses',
      'Hassan city accommodations'
    ],
    nearbyRestaurants: [
      'Jain vegetarian restaurants',
      'KSTDC restaurant',
      'Local pure vegetarian eateries',
      'Traditional Jain food centers'
    ],
    specialFeatures: [
      'World\'s largest monolithic statue (57 feet)',
      'Over 1,000 years old',
      'Mahamastakabhisheka every 12 years',
      'Important Jain pilgrimage site',
      'Vindhyagiri Hill location',
      'Carved from single granite block'
    ]
  },
  {
    id: 'ranganathaswamy-temple-srirangapatna',
    name: 'Ranganathaswamy Temple, Srirangapatna',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Srirangapatna, Mandya District',
    description: 'An ancient Vaishnavite temple dedicated to Lord Ranganatha (Vishnu), built in the 9th century. Located on the island town of Srirangapatna in the Kaveri River, it holds historical significance as the capital of Tipu Sultan\'s kingdom and features beautiful Hoysala and Vijayanagara architectural elements.',
    image: 'https://images.pexels.com/photos/12689009/pexels-photo-12689009.jpeg',
    timings: 'Morning: 6:30 AM to 2:00 PM, Evening: 3:30 PM to 8:30 PM',
    prasad: 'Vishnu prasadam, Puliyogare, Traditional offerings',
    amenities: [
      'Temple complex with multiple shrines',
      'Parking facilities',
      'Prasadam counter',
      'Historical significance displays',
      'River view location',
      'Cultural programs venue'
    ],
    festivals: [
      'Vaikuntha Ekadasi',
      'Brahmotsava',
      'Krishna Janmashtami',
      'Rathotsava',
      'Annual temple festival'
    ],
    contact: '+91 8236 252270',
    nearestTransport: {
      airport: 'Bengaluru Airport (BLR) - 125 km, Mysuru Airport (MYQ) - 18 km',
      railway: 'Srirangapatna Railway Station (SRP) - 2 km',
      bus: 'Srirangapatna Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Tipu Sultan\'s Summer Palace',
      'Gumbaz (Tipu\'s Mausoleum)',
      'Daria Daulat Bagh',
      'Colonel Bailey\'s Dungeon',
      'Kaveri River',
      'Nimishamba Temple'
    ],
    nearbyHotels: [
      'Mysuru city hotels',
      'Local guesthouses',
      'Heritage accommodations',
      'River view resorts'
    ],
    nearbyRestaurants: [
      'Local Karnataka restaurants',
      'Traditional South Indian eateries',
      'Historical town food stalls',
      'Vegetarian restaurants'
    ],
    specialFeatures: [
      'Built in 9th century',
      'Island location in Kaveri River',
      'Historical capital of Tipu Sultan',
      'Hoysala and Vijayanagara architecture',
      'Important Vaishnavite pilgrimage',
      'Cultural and historical significance'
    ]
  },
  {
    id: 'manjunatha-temple-dharmasthala',
    name: 'Manjunatha Temple, Dharmasthala',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Dharmasthala, Dakshina Kannada District',
    description: 'A unique temple dedicated to Lord Manjunatha (Shiva) where Hindu deities are worshipped but the administration is by a Jain family (Heggade family). Famous for its free meals (Annadana) serving thousands daily, it represents religious harmony and is one of the most visited pilgrimage sites in Karnataka.',
    image: 'https://images.pexels.com/photos/12689010/pexels-photo-12689010.jpeg',
    timings: 'Morning: 5:30 AM to 2:00 PM, Evening: 5:30 PM to 9:00 PM',
    prasad: 'Manjunatha prasadam, Free Annadana meals, Sacred offerings',
    amenities: [
      'Massive Annadana hall (free meals)',
      'Accommodation facilities',
      'Parking areas',
      'Museum and cultural center',
      'Ayurvedic hospital',
      'Educational institutions'
    ],
    festivals: [
      'Maha Shivaratri',
      'Lakshadeepotsava',
      'Annual Rathotsava',
      'Navaratri celebrations',
      'Cultural festivals'
    ],
    contact: '+91 8256 277216',
    website: 'https://www.dharmasthala.org',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 75 km',
      railway: 'Bantwal Railway Station (BNTL) - 29 km',
      bus: 'Dharmasthala Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Bahubali statue',
      'Manjusha Museum',
      'Nellyadi Beedu',
      'Kukke Subramanya Temple',
      'Belthangady'
    ],
    nearbyHotels: [
      'Dharmasthala Temple accommodation',
      'Yatri Nivas',
      'Local guesthouses',
      'Pilgrim lodges'
    ],
    nearbyRestaurants: [
      'Temple Annadana (free meals)',
      'Local vegetarian restaurants',
      'Traditional Karnataka eateries',
      'Pilgrim food centers'
    ],
    specialFeatures: [
      'Hindu-Jain religious harmony',
      'Heggade family administration',
      'Massive free meal service',
      'Religious and cultural center',
      'Educational and healthcare facilities',
      'Lakshadeepotsava festival with 100,000 lamps'
    ]
  },
  {
    id: 'kukke-subramanya-temple',
    name: 'Kukke Subramanya Temple',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Kukke, Dakshina Kannada District',
    description: 'A famous temple dedicated to Lord Subramanya (Kartikeya), located in the Western Ghats. Known for its Sarpa Samskara (serpent worship) rituals and believed to cure ailments caused by Sarpa Dosha (serpent curse). The temple is surrounded by lush forests and is a significant pilgrimage site.',
    image: 'https://images.pexels.com/photos/12689011/pexels-photo-12689011.jpeg',
    timings: 'Morning: 6:00 AM to 2:00 PM, Evening: 4:00 PM to 8:00 PM',
    prasad: 'Subramanya prasadam, Sarpa Samskara offerings, Traditional sweets',
    amenities: [
      'Sarpa Samskara ritual facilities',
      'Accommodation for pilgrims',
      'Parking areas',
      'Prasadam counter',
      'Natural forest surroundings',
      'Kumaradhara River access'
    ],
    festivals: [
      'Skanda Shashti',
      'Subramanya Shashti',
      'Annual Rathotsava',
      'Naga Panchami',
      'Thaipusam'
    ],
    contact: '+91 8256 258258',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 105 km',
      railway: 'Subramanya Road Railway Station (SBHR) - 8 km',
      bus: 'Kukke Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Kumaradhara River',
      'Adi Subramanya Temple',
      'Biladwara Cave',
      'Dharmasthala',
      'Western Ghats trekking'
    ],
    nearbyHotels: [
      'Temple guest houses',
      'Mayura Residency',
      'Local pilgrim accommodations',
      'Forest department rest houses'
    ],
    nearbyRestaurants: [
      'Temple prasadam centers',
      'Local vegetarian restaurants',
      'Pilgrim food stalls',
      'Traditional South Indian eateries'
    ],
    specialFeatures: [
      'Famous for Sarpa Samskara rituals',
      'Cure for Sarpa Dosha',
      'Western Ghats forest location',
      'Kumaradhara River confluence',
      'Ancient serpent worship traditions',
      'Adi Subramanya original temple nearby'
    ]
  },
  {
    id: 'sringeri-sharadamba-temple',
    name: 'Sringeri Sharadamba Temple',
    type: 'Temple',
    typeColor: 'bg-orange-100 text-orange-800',
    state: 'Karnataka',
    location: 'Sringeri, Chikkamagaluru District',
    description: 'One of the four Advaita Vedanta mathas established by Adi Shankaracharya, dedicated to Goddess Sharadamba (Saraswati). Located on the banks of the Tunga River in the Western Ghats, it is a major center of learning and spirituality, housing ancient manuscripts and conducting Vedic studies.',
    image: 'https://images.pexels.com/photos/12689012/pexels-photo-12689012.jpeg',
    timings: 'Morning: 6:30 AM to 2:00 PM, Evening: 3:00 PM to 8:30 PM',
    prasad: 'Sharadamba prasadam, Sacred offerings, Traditional sweets',
    amenities: [
      'Vedic learning center',
      'Library with ancient manuscripts',
      'Accommodation facilities',
      'Annadana hall',
      'Tunga River access',
      'Spiritual discourse halls'
    ],
    festivals: [
      'Sharadamba Navaratri',
      'Shankaracharya Jayanti',
      'Vidyarambha ceremony',
      'Annual Rathotsava',
      'Saraswati Puja'
    ],
    contact: '+91 8265 250274',
    website: 'https://www.sringeri.net',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 100 km',
      railway: 'Shimoga Railway Station (SMET) - 60 km',
      bus: 'Sringeri Bus Stand - 2 km'
    },
    nearbyAttractions: [
      'Vidyashankara Temple',
      'Tunga River',
      'Sirimane Falls',
      'Kigga',
      'Agumbe',
      'Western Ghats'
    ],
    nearbyHotels: [
      'Sringeri Mutt accommodation',
      'KSTDC Mayura Sharada',
      'Local guesthouses',
      'Pilgrim lodges'
    ],
    nearbyRestaurants: [
      'Mutt Annadana',
      'Local vegetarian restaurants',
      'Traditional South Indian eateries',
      'Pilgrim food centers'
    ],
    specialFeatures: [
      'Established by Adi Shankaracharya',
      'One of four Advaita Vedanta mathas',
      'Ancient manuscript library',
      'Vedic learning center',
      'Tunga River sacred location',
      'Continuous tradition since 8th century'
    ]
  },

  // CHURCHES
  {
    id: 'st-marys-basilica-bengaluru',
    name: 'St. Mary\'s Basilica, Bengaluru',
    type: 'Church',
    typeColor: 'bg-purple-100 text-purple-800',
    state: 'Karnataka',
    location: 'Shivajinagar, Bengaluru',
    description: 'One of the oldest churches in Bengaluru, built in 1882 in Gothic Revival style. This Roman Catholic basilica is dedicated to Our Lady of Health and is known for its beautiful stained glass windows, twin spires, and annual feast celebrations. It serves as an important spiritual center for the Christian community.',
    image: 'https://images.pexels.com/photos/12689013/pexels-photo-12689013.jpeg',
    timings: 'Daily: 6:00 AM to 7:00 PM, Mass timings vary',
    prasad: 'Holy Communion, Blessed bread, Prayer offerings',
    amenities: [
      'Prayer halls and chapels',
      'Confession booths',
      'Parking facilities',
      'Church office',
      'Religious bookstore',
      'Community hall'
    ],
    festivals: [
      'Christmas',
      'Easter',
      'Feast of Our Lady of Health',
      'Good Friday',
      'Assumption of Mary'
    ],
    contact: '+91 80 2286 4739',
    nearestTransport: {
      airport: 'Kempegowda International Airport (BLR) - 35 km',
      railway: 'Bengaluru Cantonment Railway Station (BNC) - 3 km',
      bus: 'Shivajinagar Bus Stop - 1 km'
    },
    nearbyAttractions: [
      'Cubbon Park',
      'Vidhana Soudha',
      'St. Mark\'s Cathedral',
      'UB City Mall',
      'Commercial Street'
    ],
    nearbyHotels: [
      'The Oberoi Bengaluru',
      'ITC Windsor',
      'Taj West End',
      'Various city hotels'
    ],
    nearbyRestaurants: [
      'Church Street restaurants',
      'Brigade Road eateries',
      'Commercial Street food',
      'Multi-cuisine restaurants'
    ],
    specialFeatures: [
      'Built in 1882',
      'Gothic Revival architecture',
      'Beautiful stained glass windows',
      'Twin spires design',
      'Our Lady of Health dedication',
      'Historic Christian landmark'
    ]
  },
  {
    id: 'st-philomenas-cathedral-mysuru',
    name: 'St. Philomena\'s Cathedral, Mysuru',
    type: 'Church',
    typeColor: 'bg-purple-100 text-purple-800',
    state: 'Karnataka',
    location: 'Mysuru',
    description: 'One of the largest churches in India, built in Gothic style and dedicated to St. Philomena. Constructed between 1933-1941, this magnificent cathedral features beautiful stained glass windows, twin spires reaching 175 feet, and houses relics of St. Philomena. It is an architectural marvel and important pilgrimage site.',
    image: 'https://images.pexels.com/photos/12689014/pexels-photo-12689014.jpeg',
    timings: 'Daily: 6:00 AM to 6:00 PM, Mass timings vary',
    prasad: 'Holy Communion, Blessed items, Prayer offerings',
    amenities: [
      'Large prayer hall',
      'Relic chamber',
      'Parking facilities',
      'Church museum',
      'Gift shop',
      'Guided tours available'
    ],
    festivals: [
      'Feast of St. Philomena',
      'Christmas',
      'Easter',
      'Good Friday',
      'Assumption Day'
    ],
    contact: '+91 821 2425 2594',
    nearestTransport: {
      airport: 'Mysuru Airport (MYQ) - 12 km, Bengaluru Airport (BLR) - 150 km',
      railway: 'Mysuru Junction (MYS) - 3 km',
      bus: 'Mysuru City Bus Stand - 2 km'
    },
    nearbyAttractions: [
      'Mysuru Palace',
      'Chamundi Hills',
      'Brindavan Gardens',
      'Mysuru Zoo',
      'Devaraja Market'
    ],
    nearbyHotels: [
      'Lalitha Mahal Palace Hotel',
      'Royal Orchid Metropole',
      'Hotel Pai Vista',
      'Mysuru city accommodations'
    ],
    nearbyRestaurants: [
      'Mysuru city restaurants',
      'Traditional Karnataka cuisine',
      'Multi-cuisine eateries',
      'Palace area restaurants'
    ],
    specialFeatures: [
      'One of largest churches in India',
      'Gothic architectural style',
      'Twin spires 175 feet high',
      'Houses relics of St. Philomena',
      'Beautiful stained glass windows',
      'Built between 1933-1941'
    ]
  },
  {
    id: 'st-aloysius-chapel-mangaluru',
    name: 'St. Aloysius Chapel, Mangaluru',
    type: 'Church',
    typeColor: 'bg-purple-100 text-purple-800',
    state: 'Karnataka',
    location: 'Lighthouse Hill, Mangaluru',
    description: 'A beautiful chapel known for its stunning frescoes and paintings covering the walls and ceiling, painted by Italian Jesuit Antonio Moscheni in 1899. The chapel is part of St. Aloysius College and is considered one of the finest examples of religious art in India.',
    image: 'https://images.pexels.com/photos/12689015/pexels-photo-12689015.jpeg',
    timings: 'Daily: 6:00 AM to 6:00 PM, Mass timings vary',
    prasad: 'Holy Communion, Blessed items, Prayer offerings',
    amenities: [
      'Art gallery viewing',
      'Chapel tours',
      'Parking facilities',
      'College campus access',
      'Photography permitted',
      'Educational displays'
    ],
    festivals: [
      'Christmas',
      'Easter',
      'Good Friday',
      'Feast of St. Aloysius',
      'College celebrations'
    ],
    contact: '+91 824 2449 721',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 12 km',
      railway: 'Mangaluru Central (MAQ) - 3 km',
      bus: 'Mangaluru Bus Stand - 2 km'
    },
    nearbyAttractions: [
      'Lighthouse Hill',
      'Mangaluru beaches',
      'Kadri Manjunath Temple',
      'Sultan Battery',
      'Tannirbhavi Beach'
    ],
    nearbyHotels: [
      'The Ocean Pearl',
      'Goldfinch Hotel',
      'Hotel Moti Mahal',
      'Coastal accommodations'
    ],
    nearbyRestaurants: [
      'Coastal cuisine restaurants',
      'Mangalorean specialties',
      'Multi-cuisine options',
      'College area eateries'
    ],
    specialFeatures: [
      'Stunning frescoes by Antonio Moscheni',
      'Painted in 1899',
      'Part of St. Aloysius College',
      'Finest religious art in India',
      'Italian Jesuit heritage',
      'Complete ceiling and wall paintings'
    ]
  },
  {
    id: 'st-joseph-cathedral-mangaluru',
    name: 'St. Joseph Cathedral, Mangaluru',
    type: 'Church',
    typeColor: 'bg-purple-100 text-purple-800',
    state: 'Karnataka',
    location: 'Rosario Cathedral Road, Mangaluru',
    description: 'The cathedral church of the Roman Catholic Diocese of Mangaluru, built in 1910. It serves as the mother church for Catholics in the region and is known for its beautiful architecture and spiritual significance.',
    image: 'https://images.pexels.com/photos/12689016/pexels-photo-12689016.jpeg',
    timings: 'Daily: 6:00 AM to 7:00 PM, Mass timings vary',
    prasad: 'Holy Communion, Blessed items, Cathedral offerings',
    amenities: [
      'Large cathedral nave',
      'Bishop\'s seat',
      'Confession facilities',
      'Parking area',
      'Church office',
      'Religious education center'
    ],
    festivals: [
      'Christmas',
      'Easter',
      'Good Friday',
      'Feast of St. Joseph',
      'Diocese celebrations'
    ],
    contact: '+91 824 2425 679',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 10 km',
      railway: 'Mangaluru Central (MAQ) - 2 km',
      bus: 'Mangaluru Bus Stand - 1.5 km'
    },
    nearbyAttractions: [
      'Rosario Cathedral area',
      'Mangaluru city center',
      'Coastal attractions',
      'Local markets'
    ],
    nearbyHotels: [
      'Cathedral area hotels',
      'City center accommodations',
      'Business hotels'
    ],
    nearbyRestaurants: [
      'Cathedral area restaurants',
      'Local Mangalorean cuisine',
      'Multi-cuisine eateries'
    ],
    specialFeatures: [
      'Cathedral of Mangaluru Diocese',
      'Built in 1910',
      'Mother church for regional Catholics',
      'Beautiful cathedral architecture',
      'Bishop\'s seat',
      'Diocesan administrative center'
    ]
  },
  {
    id: 'holy-rosary-church-shivamogga',
    name: 'Holy Rosary Church, Shivamogga',
    type: 'Church',
    typeColor: 'bg-purple-100 text-purple-800',
    state: 'Karnataka',
    location: 'Shivamogga',
    description: 'A prominent Catholic church in Shivamogga, serving the Christian community in the Malnad region. Known for its peaceful atmosphere and community service programs.',
    image: 'https://images.pexels.com/photos/12689017/pexels-photo-12689017.jpeg',
    timings: 'Daily: 6:00 AM to 7:00 PM, Mass timings vary',
    prasad: 'Holy Communion, Blessed items, Prayer offerings',
    amenities: [
      'Prayer hall',
      'Community center',
      'Parking facilities',
      'Religious education',
      'Social service programs',
      'Youth activities'
    ],
    festivals: [
      'Christmas',
      'Easter',
      'Good Friday',
      'Feast of Holy Rosary',
      'Community celebrations'
    ],
    contact: '+91 8182 225 678',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 140 km',
      railway: 'Shivamogga Town Railway Station (SMET) - 3 km',
      bus: 'Shivamogga Bus Stand - 2 km'
    },
    nearbyAttractions: [
      'Shivamogga city attractions',
      'Jog Falls (nearby)',
      'Tyavarekoppa Lion Safari',
      'Koodlu Theertha Falls'
    ],
    nearbyHotels: [
      'Shivamogga city hotels',
      'Local accommodations',
      'Budget lodges'
    ],
    nearbyRestaurants: [
      'Local restaurants',
      'Malnad cuisine',
      'Multi-cuisine eateries'
    ],
    specialFeatures: [
      'Serves Malnad region Christians',
      'Community service focus',
      'Peaceful worship environment',
      'Youth and social programs',
      'Regional Christian center'
    ]
  },

  // MOSQUES
  {
    id: 'jamia-masjid-bengaluru',
    name: 'Jamia Masjid, Bengaluru',
    type: 'Mosque',
    typeColor: 'bg-green-100 text-green-800',
    state: 'Karnataka',
    location: 'Russell Market, Shivajinagar, Bengaluru',
    description: 'One of the oldest and largest mosques in Bengaluru, built in the 19th century. It serves as a central place of worship for the Muslim community and is known for its beautiful Indo-Islamic architecture with traditional minarets and domes.',
    image: 'https://images.pexels.com/photos/12689018/pexels-photo-12689018.jpeg',
    timings: 'Five daily prayers, Friday Juma prayers especially well-attended',
    prasad: 'Community Iftar meals, Charitable food distribution',
    amenities: [
      'Large prayer hall',
      'Separate women\'s section',
      'Ablution facilities (Wudu)',
      'Community hall',
      'Islamic education center',
      'Parking area'
    ],
    festivals: [
      'Eid al-Fitr',
      'Eid al-Adha',
      'Milad-un-Nabi',
      'Ramadan special prayers',
      'Islamic New Year'
    ],
    contact: '+91 80 2287 5432',
    nearestTransport: {
      airport: 'Kempegowda International Airport (BLR) - 35 km',
      railway: 'Bengaluru City Railway Station (SBC) - 2 km',
      bus: 'Shivajinagar Bus Stop - 1 km'
    },
    nearbyAttractions: [
      'Russell Market',
      'Cubbon Park',
      'Vidhana Soudha',
      'Commercial Street',
      'St. Mary\'s Basilica'
    ],
    nearbyHotels: [
      'City center hotels',
      'Shivajinagar accommodations',
      'Budget lodges'
    ],
    nearbyRestaurants: [
      'Halal restaurants',
      'Russell Market eateries',
      'Traditional Muslim cuisine',
      'Multi-cuisine options'
    ],
    specialFeatures: [
      'One of oldest mosques in Bengaluru',
      'Built in 19th century',
      'Indo-Islamic architecture',
      'Central Muslim community hub',
      'Traditional minarets and domes',
      'Historical significance'
    ]
  },
  {
    id: 'masjid-e-khadria-bengaluru',
    name: 'Masjid-e-Khadria, Bengaluru',
    type: 'Mosque',
    typeColor: 'bg-green-100 text-green-800',
    state: 'Karnataka',
    location: 'Frazer Town, Bengaluru',
    description: 'A prominent mosque in Frazer Town area, known for its community service and religious education programs. It serves the local Muslim population with regular prayers and Islamic teachings.',
    image: 'https://images.pexels.com/photos/12689019/pexels-photo-12689019.jpeg',
    timings: 'Five daily prayers, special congregational prayers',
    prasad: 'Community meals during festivals, Charitable distributions',
    amenities: [
      'Prayer hall',
      'Islamic education center',
      'Community service programs',
      'Ablution facilities',
      'Parking area',
      'Youth programs'
    ],
    festivals: [
      'Eid al-Fitr',
      'Eid al-Adha',
      'Milad-un-Nabi',
      'Ramadan programs',
      'Islamic calendar observances'
    ],
    contact: '+91 80 2546 7890',
    nearestTransport: {
      airport: 'Kempegowda International Airport (BLR) - 38 km',
      railway: 'Bengaluru Cantonment Railway Station (BNC) - 2 km',
      bus: 'Frazer Town Bus Stop - 1 km'
    },
    nearbyAttractions: [
      'Frazer Town area',
      'Ulsoor Lake',
      'Cubbon Park',
      'Commercial Street'
    ],
    nearbyHotels: [
      'Frazer Town accommodations',
      'Cantonment area hotels',
      'Local guesthouses'
    ],
    nearbyRestaurants: [
      'Halal restaurants',
      'Local Muslim cuisine',
      'Frazer Town eateries'
    ],
    specialFeatures: [
      'Community service focus',
      'Islamic education programs',
      'Youth development activities',
      'Local Muslim community center',
      'Religious and social services'
    ]
  },
  {
    id: 'jama-masjid-mysuru',
    name: 'Jama Masjid, Mysuru',
    type: 'Mosque',
    typeColor: 'bg-green-100 text-green-800',
    state: 'Karnataka',
    location: 'Mysuru',
    description: 'The main mosque in Mysuru, serving the Muslim community in the heritage city. Built during the Tipu Sultan era, it reflects the Islamic architectural heritage of the region.',
    image: 'https://images.pexels.com/photos/12689020/pexels-photo-12689020.jpeg',
    timings: 'Five daily prayers, Friday Juma prayers',
    prasad: 'Community Iftar, Festival meals',
    amenities: [
      'Main prayer hall',
      'Courtyard for gatherings',
      'Ablution facilities',
      'Islamic education',
      'Community programs',
      'Historical significance'
    ],
    festivals: [
      'Eid al-Fitr',
      'Eid al-Adha',
      'Milad-un-Nabi',
      'Ramadan observances',
      'Islamic celebrations'
    ],
    contact: '+91 821 2423 456',
    nearestTransport: {
      airport: 'Mysuru Airport (MYQ) - 15 km',
      railway: 'Mysuru Junction (MYS) - 3 km',
      bus: 'Mysuru City Bus Stand - 2 km'
    },
    nearbyAttractions: [
      'Mysuru Palace',
      'Tipu Sultan\'s Summer Palace',
      'Chamundi Hills',
      'Devaraja Market'
    ],
    nearbyHotels: [
      'Mysuru city hotels',
      'Heritage accommodations',
      'Palace area hotels'
    ],
    nearbyRestaurants: [
      'Halal restaurants',
      'Traditional Muslim cuisine',
      'Mysuru local eateries'
    ],
    specialFeatures: [
      'Built during Tipu Sultan era',
      'Islamic architectural heritage',
      'Main mosque of Mysuru',
      'Historical significance',
      'Community religious center'
    ]
  },
  {
    id: 'masjid-e-azam-mangaluru',
    name: 'Masjid-e-Azam, Mangaluru',
    type: 'Mosque',
    typeColor: 'bg-green-100 text-green-800',
    state: 'Karnataka',
    location: 'Bunder, Mangaluru',
    description: 'A significant mosque in the coastal city of Mangaluru, serving the large Muslim population. Known for its community service and religious education programs.',
    image: 'https://images.pexels.com/photos/12689021/pexels-photo-12689021.jpeg',
    timings: 'Five daily prayers, special Friday prayers',
    prasad: 'Community meals, Charitable distributions',
    amenities: [
      'Large prayer hall',
      'Community center',
      'Islamic education',
      'Ablution facilities',
      'Social service programs',
      'Youth activities'
    ],
    festivals: [
      'Eid al-Fitr',
      'Eid al-Adha',
      'Milad-un-Nabi',
      'Ramadan programs',
      'Community celebrations'
    ],
    contact: '+91 824 2441 234',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 12 km',
      railway: 'Mangaluru Central (MAQ) - 2 km',
      bus: 'Mangaluru Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Mangaluru port area',
      'Coastal beaches',
      'Sultan Battery',
      'Local markets'
    ],
    nearbyHotels: [
      'Coastal hotels',
      'Port area accommodations',
      'Business hotels'
    ],
    nearbyRestaurants: [
      'Halal restaurants',
      'Coastal Muslim cuisine',
      'Seafood specialties'
    ],
    specialFeatures: [
      'Serves coastal Muslim community',
      'Community service focus',
      'Islamic education center',
      'Port city location',
      'Cultural preservation'
    ]
  },
  {
    id: 'hazrat-tipu-sultan-masjid-bengaluru',
    name: 'Hazrat Tipu Sultan Masjid, Bengaluru',
    type: 'Mosque',
    typeColor: 'bg-green-100 text-green-800',
    state: 'Karnataka',
    location: 'KR Market, Bengaluru',
    description: 'A historic mosque named after Tipu Sultan, located in the bustling KR Market area. It serves as an important religious and cultural center for the Muslim community.',
    image: 'https://images.pexels.com/photos/12689022/pexels-photo-12689022.jpeg',
    timings: 'Five daily prayers, Friday congregational prayers',
    prasad: 'Community Iftar meals, Festival distributions',
    amenities: [
      'Prayer hall',
      'Historical significance',
      'Community gathering space',
      'Ablution facilities',
      'Religious education',
      'Cultural programs'
    ],
    festivals: [
      'Eid al-Fitr',
      'Eid al-Adha',
      'Milad-un-Nabi',
      'Tipu Sultan commemorations',
      'Islamic festivals'
    ],
    contact: '+91 80 2670 1234',
    nearestTransport: {
      airport: 'Kempegowda International Airport (BLR) - 40 km',
      railway: 'Bengaluru City Railway Station (SBC) - 3 km',
      bus: 'KR Market Bus Stop - nearby'
    },
    nearbyAttractions: [
      'KR Market',
      'Tipu Sultan\'s Summer Palace',
      'Bull Temple',
      'Lalbagh Botanical Garden'
    ],
    nearbyHotels: [
      'KR Market area hotels',
      'City center accommodations',
      'Budget lodges'
    ],
    nearbyRestaurants: [
      'Halal restaurants',
      'KR Market eateries',
      'Traditional Muslim cuisine'
    ],
    specialFeatures: [
      'Named after Tipu Sultan',
      'Historical significance',
      'KR Market location',
      'Cultural heritage preservation',
      'Community religious center'
    ]
  },

  // GURUDWARAS
  {
    id: 'gurudwara-guru-singh-sabha-bengaluru',
    name: 'Gurudwara Guru Singh Sabha, Bengaluru',
    type: 'Gurudwara',
    typeColor: 'bg-blue-100 text-blue-800',
    state: 'Karnataka',
    location: 'Ulsoor, Bengaluru',
    description: 'The main Gurudwara in Bengaluru, serving the Sikh community in the city. It provides a spiritual center for worship, community gatherings, and cultural activities, maintaining the traditions of Sikhism in Karnataka\'s capital.',
    image: 'https://images.pexels.com/photos/12689006/pexels-photo-12689006.jpeg',
    timings: 'Early morning to evening (specific times vary)',
    prasad: 'Langar (community kitchen), Karah Prasad',
    amenities: [
      'Darbar Sahib (prayer hall)',
      'Langar hall for community meals',
      'Parking facilities',
      'Community center',
      'Religious education facilities',
      'Guest accommodation'
    ],
    festivals: [
      'Guru Nanak Jayanti',
      'Baisakhi',
      'Guru Gobind Singh Jayanti',
      'Diwali',
      'Hola Mohalla'
    ],
    contact: '+91 80 2558 4444',
    nearestTransport: {
      airport: 'Kempegowda International Airport (BLR) - 35 km',
      railway: 'Bengaluru Cantonment Railway Station (BNC) - 3 km',
      bus: 'Ulsoor Bus Stop - 1 km'
    },
    nearbyAttractions: [
      'Ulsoor Lake',
      'Cubbon Park',
      'Vidhana Soudha',
      'Commercial Street',
      'St. Mark\'s Cathedral'
    ],
    nearbyHotels: [
      'The Oberoi Bengaluru',
      'ITC Windsor',
      'Taj West End',
      'Various city hotels'
    ],
    nearbyRestaurants: [
      'Gurudwara Langar',
      'Punjabi restaurants in city',
      'Ulsoor area eateries',
      'Multi-cuisine restaurants'
    ],
    specialFeatures: [
      'Main Sikh center in Bengaluru',
      'Active community service programs',
      'Regular langar service',
      'Cultural and religious education',
      'Community gathering place',
      'Interfaith harmony promotion'
    ]
  },
  {
    id: 'gurudwara-guru-singh-sabha-mysuru',
    name: 'Gurudwara Guru Singh Sabha, Mysuru',
    type: 'Gurudwara',
    typeColor: 'bg-blue-100 text-blue-800',
    state: 'Karnataka',
    location: 'Mysuru',
    description: 'A Gurudwara serving the Sikh community in Mysuru, providing spiritual guidance and community services. It maintains Sikh traditions and offers a place for worship and cultural activities in the heritage city of Mysuru.',
    image: 'https://images.pexels.com/photos/12689015/pexels-photo-12689015.jpeg',
    timings: 'Early morning to evening (specific times vary)',
    prasad: 'Langar (community kitchen), Karah Prasad',
    amenities: [
      'Prayer hall',
      'Langar hall',
      'Parking facilities',
      'Community center',
      'Religious education',
      'Guest facilities'
    ],
    festivals: [
      'Guru Nanak Jayanti',
      'Baisakhi',
      'Guru Gobind Singh Jayanti',
      'Diwali',
      'Hola Mohalla'
    ],
    contact: '+91 821 2423 789',
    nearestTransport: {
      airport: 'Mysuru Airport (MYQ) - 15 km',
      railway: 'Mysuru Junction (MYS) - 4 km',
      bus: 'Mysuru City Bus Stand - 3 km'
    },
    nearbyAttractions: [
      'Mysuru Palace',
      'Chamundi Hills',
      'St. Philomena\'s Cathedral',
      'Brindavan Gardens',
      'Mysuru Zoo'
    ],
    nearbyHotels: [
      'Mysuru city hotels',
      'Palace area accommodations',
      'Budget lodges',
      'Heritage hotels'
    ],
    nearbyRestaurants: [
      'Gurudwara Langar',
      'Mysuru local restaurants',
      'Traditional Karnataka cuisine',
      'Multi-cuisine eateries'
    ],
    specialFeatures: [
      'Sikh community center in Mysuru',
      'Cultural preservation',
      'Community service programs',
      'Religious education',
      'Interfaith dialogue',
      'Heritage city location'
    ]
  },
  {
    id: 'gurudwara-guru-singh-sabha-mangaluru',
    name: 'Gurudwara Guru Singh Sabha, Mangaluru',
    type: 'Gurudwara',
    typeColor: 'bg-blue-100 text-blue-800',
    state: 'Karnataka',
    location: 'Mangaluru',
    description: 'A Gurudwara serving the Sikh community in the coastal city of Mangaluru. It provides spiritual services and community support while maintaining Sikh traditions in this important port city of Karnataka.',
    image: 'https://images.pexels.com/photos/12689016/pexels-photo-12689016.jpeg',
    timings: 'Early morning to evening (specific times vary)',
    prasad: 'Langar (community kitchen), Karah Prasad',
    amenities: [
      'Darbar Sahib',
      'Langar hall',
      'Limited parking',
      'Community facilities',
      'Religious education',
      'Basic accommodation'
    ],
    festivals: [
      'Guru Nanak Jayanti',
      'Baisakhi',
      'Guru Gobind Singh Jayanti',
      'Diwali',
      'Hola Mohalla'
    ],
    contact: '+91 824 2441 567',
    nearestTransport: {
      airport: 'Mangaluru International Airport (IXE) - 12 km',
      railway: 'Mangaluru Central (MAQ) - 3 km',
      bus: 'Mangaluru Bus Stand - 2 km'
    },
    nearbyAttractions: [
      'Mangaluru beaches',
      'Kadri Manjunath Temple',
      'St. Aloysius Chapel',
      'Tannirbhavi Beach',
      'Sultan Battery'
    ],
    nearbyHotels: [
      'Mangaluru city hotels',
      'Coastal resorts',
      'Business hotels',
      'Budget accommodations'
    ],
    nearbyRestaurants: [
      'Gurudwara Langar',
      'Coastal cuisine restaurants',
      'Mangalorean specialties',
      'Multi-cuisine options'
    ],
    specialFeatures: [
      'Coastal city Sikh center',
      'Community gathering place',
      'Cultural activities',
      'Religious services',
      'Port city location',
      'Interfaith harmony'
    ]
  },
  {
    id: 'gurudwara-sahib-hubballi',
    name: 'Gurudwara Sahib, Hubballi',
    type: 'Gurudwara',
    typeColor: 'bg-blue-100 text-blue-800',
    state: 'Karnataka',
    location: 'Hubballi',
    description: 'A Gurudwara serving the Sikh community in Hubballi-Dharwad region. It provides religious services and community support in this important commercial and educational center of North Karnataka.',
    image: 'https://images.pexels.com/photos/12689023/pexels-photo-12689023.jpeg',
    timings: 'Early morning to evening prayers',
    prasad: 'Langar (community kitchen), Karah Prasad',
    amenities: [
      'Prayer hall',
      'Langar facilities',
      'Community center',
      'Religious education',
      'Parking area',
      'Guest accommodation'
    ],
    festivals: [
      'Guru Nanak Jayanti',
      'Baisakhi',
      'Guru Gobind Singh Jayanti',
      'Diwali',
      'Community celebrations'
    ],
    contact: '+91 836 2234 567',
    nearestTransport: {
      airport: 'Hubballi Airport (HBX) - 8 km',
      railway: 'Hubballi Junction (UBL) - 3 km',
      bus: 'Hubballi Bus Stand - 2 km'
    },
    nearbyAttractions: [
      'Unkal Lake',
      'Nrupatunga Betta',
      'Dharwad attractions',
      'Educational institutions'
    ],
    nearbyHotels: [
      'Hubballi city hotels',
      'Business accommodations',
      'Budget lodges'
    ],
    nearbyRestaurants: [
      'Gurudwara Langar',
      'North Karnataka cuisine',
      'Multi-cuisine restaurants'
    ],
    specialFeatures: [
      'Serves North Karnataka Sikhs',
      'Commercial center location',
      'Educational hub proximity',
      'Community service focus',
      'Regional Sikh center'
    ]
  },
  {
    id: 'gurudwara-sahib-bijapur',
    name: 'Gurudwara Sahib, Bijapur',
    type: 'Gurudwara',
    typeColor: 'bg-blue-100 text-blue-800',
    state: 'Karnataka',
    location: 'Bijapur (Vijayapura)',
    description: 'A Gurudwara in the historic city of Bijapur, serving the local Sikh community. It provides spiritual services in this city known for its Islamic architecture and historical monuments.',
    image: 'https://images.pexels.com/photos/12689024/pexels-photo-12689024.jpeg',
    timings: 'Morning and evening prayers',
    prasad: 'Langar (community kitchen), Karah Prasad',
    amenities: [
      'Prayer hall',
      'Community facilities',
      'Basic amenities',
      'Religious education',
      'Cultural programs'
    ],
    festivals: [
      'Guru Nanak Jayanti',
      'Baisakhi',
      'Guru Gobind Singh Jayanti',
      'Sikh festivals'
    ],
    contact: '+91 8352 234 567',
    nearestTransport: {
      airport: 'Hubballi Airport (HBX) - 200 km',
      railway: 'Bijapur Railway Station (BJP) - 2 km',
      bus: 'Bijapur Bus Stand - 1 km'
    },
    nearbyAttractions: [
      'Gol Gumbaz',
      'Ibrahim Rauza',
      'Jumma Masjid',
      'Bijapur Fort',
      'Historical monuments'
    ],
    nearbyHotels: [
      'Bijapur heritage hotels',
      'Local accommodations',
      'Budget lodges'
    ],
    nearbyRestaurants: [
      'Gurudwara Langar',
      'Local restaurants',
      'Traditional cuisine'
    ],
    specialFeatures: [
      'Historic city location',
      'Interfaith harmony',
      'Cultural diversity',
      'Heritage city service',
      'Community integration'
    ]
  }
];